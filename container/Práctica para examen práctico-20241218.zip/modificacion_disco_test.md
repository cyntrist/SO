Modificar la práctica 5 (discoteca) para añadir la siguiente funcionalidad:

Cuando un cliente llegue a la discoteca, si ve que hay cola, se irá al bar de al lado. 
En el bar se emborrachará durante un rato (aleatorio).
Al salir tardará otro tiempo aleatorio antes de volver a intentar entrar en la discoteca.

El bar es un sitio más caótico, donde, aunque hay también una cola, 
no se respetan turnos, y el ser VIP no tiene efecto.

Implementa este comportamiento, modificando el archivo de entrada para poder indicar
cuántos taburetes (plazas) tiene el bar, además de añadir los clientes suficientes como para que
tanto bar como discoteca acaben con clientes en la cola.
