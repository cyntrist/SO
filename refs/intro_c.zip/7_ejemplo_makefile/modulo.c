#include "modulo.h"
#include <stdio.h>

int mydata=0;

void myproc(void){
	printf("Hola mundo: \n");
}
