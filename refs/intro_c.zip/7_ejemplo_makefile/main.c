#include <stdio.h>
#include "modulo.h"

void main(void){
	printf("Imported value is %d\n", mydata);
	myproc();
}
