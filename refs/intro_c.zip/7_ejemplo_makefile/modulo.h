void myproc(void);
extern int mydata;
